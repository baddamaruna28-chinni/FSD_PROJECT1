/* SkillSprout core: pure logic, no DOM, no storage.
   Works in the browser (window.Core) and Node (require) so it can be unit-tested
   and reused by the server for validation. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Core = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const MODULE_COUNT = 4;
  const SEMESTER_CREDIT_LIMIT = 16;
  const CAREERS = ["Full-Stack Web", "AI & ML", "Cybersecurity", "Software Development"];
  const EXPERIENCE = ["beginner", "basic", "intermediate"];
  const BRANCHES = ["Computer Science & Engineering", "Information Technology", "AI & Data Science",
    "Electronics & Communication", "Electrical Engineering", "Mechanical Engineering"];

  /* ---------- Course graph ---------- */

  /** Returns a list of human-readable problems in the catalogue (empty = valid). */
  function validateCourses(courses) {
    const problems = [];
    if (!Array.isArray(courses)) return ["Course list is not an array."];
    const codes = new Set();
    courses.forEach((c) => {
      if (!c || typeof c.code !== "string") return problems.push("Course without a code.");
      if (codes.has(c.code)) problems.push(`Duplicate course code ${c.code}.`);
      codes.add(c.code);
      if (!Array.isArray(c.prerequisites)) problems.push(`${c.code}: prerequisites must be an array.`);
      if (!Number.isInteger(c.credits) || c.credits <= 0) problems.push(`${c.code}: invalid credits.`);
    });
    courses.forEach((c) => (c.prerequisites || []).forEach((p) => {
      if (!codes.has(p)) problems.push(`${c.code}: unknown prerequisite ${p}.`);
      if (p === c.code) problems.push(`${c.code}: course requires itself.`);
    }));
    return problems;
  }

  /** Kahn's algorithm. Unknown prerequisites are ignored. On a cycle, `cycle` lists the stuck codes. */
  function topologicalSort(courses) {
    const inDegree = new Map(), next = new Map();
    courses.forEach((c) => { inDegree.set(c.code, 0); next.set(c.code, []); });
    courses.forEach((c) => {
      new Set(c.prerequisites).forEach((p) => {
        if (!inDegree.has(p)) return;
        inDegree.set(c.code, inDegree.get(c.code) + 1);
        next.get(p).push(c.code);
      });
    });
    const ready = courses.filter((c) => inDegree.get(c.code) === 0).map((c) => c.code);
    const orderedCodes = [];
    for (let i = 0; i < ready.length; i++) {          // index walk: O(n), no shift()
      orderedCodes.push(ready[i]);
      next.get(ready[i]).forEach((n) => {
        inDegree.set(n, inDegree.get(n) - 1);
        if (inDegree.get(n) === 0) ready.push(n);
      });
    }
    const cycle = courses.map((c) => c.code).filter((c) => !orderedCodes.includes(c));
    return { orderedCodes, hasCycle: cycle.length > 0, cycle };
  }

  /** Core + chosen pathway (+ transitive prerequisites), in prerequisite order. */
  function buildRecommendedPath(courses, career) {
    const byCode = new Map(courses.map((c) => [c.code, c]));
    const chosen = new Set(courses.filter((c) => c.track === "Core" || c.track === career).map((c) => c.code));
    const addPrereqs = (code) => (byCode.get(code)?.prerequisites || []).forEach((p) => {
      if (byCode.has(p) && !chosen.has(p)) { chosen.add(p); addPrereqs(p); }
    });
    [...chosen].forEach(addPrereqs);
    const result = topologicalSort(courses.filter((c) => chosen.has(c.code)));
    if (result.hasCycle) return { courses: [], error: `Circular prerequisite: ${result.cycle.join(", ")}` };
    return { courses: result.orderedCodes.map((c) => byCode.get(c)), error: null };
  }

  /** Spreads the path over `count` semesters; a course never lands before its prerequisites. */
  function createSemesterPlan(path, count = 4, limit = SEMESTER_CREDIT_LIMIT) {
    const plan = Array.from({ length: count }, () => []);
    const totals = new Array(count).fill(0), placed = new Map();
    path.forEach((c) => {
      const min = Math.max(0, ...c.prerequisites.filter((p) => placed.has(p)).map((p) => placed.get(p) + 1));
      let idx = totals.findIndex((t, i) => i >= min && t + c.credits <= limit);
      if (idx === -1) idx = Math.min(min, count - 1);   // overflow is reported by the audit
      plan[idx].push(c); totals[idx] += c.credits; placed.set(c.code, idx);
    });
    return plan;
  }

  /* ---------- Student state ---------- */

  const isCourseComplete = (state, code) => (state.completedModules[code] || []).length >= MODULE_COUNT;

  function missingPrerequisites(state, course) {
    return course.prerequisites.filter((p) => !isCourseComplete(state, p));
  }

  /** Clean any untrusted state (localStorage, request body). Never throws. */
  function sanitizeState(raw, courses, fallback) {
    const base = fallback || { profile: {}, enrolled: [], completedModules: {} };
    const known = new Set(courses.map((c) => c.code));
    const src = raw && typeof raw === "object" ? raw : {};
    const p = src.profile && typeof src.profile === "object" ? src.profile : {};
    const profile = {
      name: typeof p.name === "string" ? p.name.replace(/[<>\u0000-\u001f]/g, "").trim().slice(0, 60) : base.profile.name,
      branch: BRANCHES.includes(p.branch) ? p.branch : base.profile.branch,
      semester: /^[1-8]$/.test(String(p.semester)) ? String(p.semester) : base.profile.semester,
      experience: EXPERIENCE.includes(p.experience) ? p.experience : base.profile.experience,
      career: CAREERS.includes(p.career) ? p.career : base.profile.career
    };
    const enrolled = [...new Set(Array.isArray(src.enrolled) ? src.enrolled : base.enrolled)]
      .filter((c) => typeof c === "string" && known.has(c));
    const completedModules = {};
    Object.entries(src.completedModules && typeof src.completedModules === "object" ? src.completedModules : {})
      .forEach(([code, mods]) => {
        if (!known.has(code) || !Array.isArray(mods)) return;
        completedModules[code] = [...new Set(mods)].filter((m) => Number.isInteger(m) && m >= 1 && m <= MODULE_COUNT);
      });
    return { profile, enrolled, completedModules };
  }

  function validateProfile(input) {
    const errors = {};
    const name = String(input.name || "").trim();
    if (name.length < 2) errors.name = "Enter at least 2 characters.";
    else if (name.length > 60) errors.name = "Keep the name under 60 characters.";
    else if (!/^[\p{L}][\p{L} .'\-]*$/u.test(name)) errors.name = "Use letters, spaces, . ' or - only.";
    if (!BRANCHES.includes(input.branch)) errors.branch = "Choose a listed branch.";
    if (!/^[1-8]$/.test(String(input.semester))) errors.semester = "Semester must be 1-8.";
    if (!EXPERIENCE.includes(input.experience)) errors.experience = "Choose a listed level.";
    if (!CAREERS.includes(input.career)) errors.career = "Choose a listed pathway.";
    return { valid: Object.keys(errors).length === 0, errors };
  }

  /* ---------- Advisor Audit ---------- */

  /** Rule-based degree-plan review. Returns findings, a 0-100 health score and a verdict. */
  function advisorAudit(state, courses) {
    const byCode = new Map(courses.map((c) => [c.code, c]));
    const findings = [];
    const add = (severity, rule, message, fix) => findings.push({ severity, rule, message, fix });
    const enrolled = state.enrolled.map((c) => byCode.get(c)).filter(Boolean);

    const dataProblems = validateCourses(courses);
    dataProblems.forEach((m) => add("critical", "DATA", m, "Fix the catalogue in courses.js."));
    const sorted = topologicalSort(courses);
    if (sorted.hasCycle) add("critical", "CYCLE", `Circular prerequisites: ${sorted.cycle.join(", ")}.`, "Break the loop in courses.js.");

    // R1: enrolled without prerequisites satisfied
    enrolled.forEach((c) => {
      const missing = missingPrerequisites(state, c);
      if (missing.length && !isCourseComplete(state, c.code) && (state.completedModules[c.code] || []).length > 0)
        add("critical", "PREREQ", `${c.code} has progress but ${missing.join(", ")} not completed.`, `Finish ${missing.join(", ")} first.`);
      else if (missing.length && !isCourseComplete(state, c.code))
        add("warning", "PREREQ", `${c.code} is enrolled before ${missing.join(", ")} is complete.`, `Prioritise ${missing.join(", ")}.`);
    });

    // R2: workload
    const hours = enrolled.filter((c) => !isCourseComplete(state, c.code))
      .reduce((s, c) => s + ({ Easy: 2, Medium: 3, Hard: 5 }[c.difficulty] || 2), 0);
    const activeCredits = enrolled.filter((c) => !isCourseComplete(state, c.code)).reduce((s, c) => s + c.credits, 0);
    if (activeCredits > SEMESTER_CREDIT_LIMIT) add("warning", "LOAD", `${activeCredits} active credits exceeds the ${SEMESTER_CREDIT_LIMIT}-credit limit.`, "Finish a course before enrolling in another.");
    if (hours > 20) add("warning", "HOURS", `Estimated ${hours} study hrs/week is very high.`, "Drop or defer a Hard course.");
    const hardActive = enrolled.filter((c) => c.difficulty === "Hard" && !isCourseComplete(state, c.code)).length;
    if (hardActive > 2) add("warning", "HARD", `${hardActive} Hard courses at once.`, "Limit Hard courses to two per term.");

    // R3: pathway coverage
    const path = buildRecommendedPath(courses, state.profile.career).courses;
    const pathCodes = new Set(path.map((c) => c.code));
    const inPath = enrolled.filter((c) => pathCodes.has(c.code)).length;
    const offPath = enrolled.filter((c) => !pathCodes.has(c.code));
    if (offPath.length) add("info", "OFFPATH", `${offPath.map((c) => c.code).join(", ")} sit outside your ${state.profile.career} roadmap.`, "Fine as electives, but they don't advance your goal.");
    if (state.profile.experience === "beginner" && enrolled.some((c) => c.difficulty === "Hard"))
      add("warning", "LEVEL", "A Hard course is enrolled while your level is 'beginner'.", "Build foundations before Hard courses.");

    // R4: foundations
    const foundations = path.filter((c) => c.prerequisites.length === 0);
    const foundDone = foundations.filter((c) => isCourseComplete(state, c.code)).length;
    if (foundations.length && foundDone === 0) add("info", "FOUNDATION", "No foundation course is complete yet.", `Start with ${foundations[0].code} ${foundations[0].title}.`);

    // R5: stalled / empty
    if (!enrolled.length) add("warning", "EMPTY", "You are not enrolled in any course.", "Enroll in an unlocked course from the catalog.");
    if (state.enrolled.length && enrolled.every((c) => (state.completedModules[c.code] || []).length === 0))
      add("info", "STALLED", "No modules completed in any enrolled course.", "Tick off one module to build momentum.");

    const penalty = { critical: 25, warning: 10, info: 3 };
    const score = Math.max(0, 100 - findings.reduce((s, f) => s + penalty[f.severity], 0));
    const pathComplete = path.filter((c) => isCourseComplete(state, c.code)).length;
    return {
      findings, score,
      verdict: score >= 90 ? "On track" : score >= 70 ? "Needs attention" : "At risk",
      coverage: { pathTotal: path.length, pathComplete, pathEnrolled: inPath },
      workload: { hours, activeCredits }
    };
  }

  return { MODULE_COUNT, SEMESTER_CREDIT_LIMIT, CAREERS, EXPERIENCE, BRANCHES, validateCourses, topologicalSort,
    buildRecommendedPath, createSemesterPlan, isCourseComplete, missingPrerequisites, sanitizeState,
    validateProfile, advisorAudit };
});
