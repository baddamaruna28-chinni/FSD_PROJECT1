/* SkillSprout LearnLoop
   Frontend prototype: browser state is saved in localStorage.
   Course records live separately in courses.js so they are easy to edit.
*/
const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "skillsprout_learnloop_final_v1";
const MODULE_COUNT = Core.MODULE_COUNT;
const PAGE_SIZE = 12;
let catalogPage = 1;

const starterState = {
  profile: {
    name: "Yogi",
    branch: "Computer Science & Engineering",
    semester: "1",
    experience: "beginner",
    career: "Full-Stack Web"
  },
  enrolled: ["CS101"],
  completedModules: { CS101: [1] }
};

let state = loadState();

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return structuredClone(starterState);
    return Core.sanitizeState(JSON.parse(raw), COURSES, starterState);
  } catch (error) {
    console.warn("Saved SkillSprout data could not be read:", error);
    return structuredClone(starterState);
  }
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (error) {
    console.warn("Could not save SkillSprout data:", error);
  }
  clearTimeout(saveState.timer);
  saveState.timer = setTimeout(() => Api.save(state), 300);   // no-op when the server is offline
}

function getCourse(code) {
  return Array.isArray(COURSES) ? COURSES.find((item) => item.code === code) : undefined;
}

function isEnrolled(code) {
  return state.enrolled.includes(code);
}

function modulesDone(code) {
  const done = state.completedModules[code];
  return Array.isArray(done) ? done : [];
}

function isCourseComplete(code) {
  return Core.isCourseComplete(state, code);
}

function isPrerequisiteComplete(code) {
  const item = getCourse(code);
  return Boolean(item) && Core.missingPrerequisites(state, item).length === 0;
}

function notify(message) {
  const toast = $("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove("show");
  void toast.offsetWidth; // trigger reflow for repeat animations
  toast.classList.add("show");
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove("show"), 2800);
}

/* Graph logic lives in core.js (unit-tested). These wrappers only adapt it to the UI. */
function createSemesterPlan() {
  const { courses, error } = Core.buildRecommendedPath(COURSES, state.profile.career);
  if (error) notify(error);
  return Core.createSemesterPlan(courses, 4);
}

function openView(viewName) {
  const targetView = $(viewName + "View");
  if (!targetView) return;

  document.querySelectorAll(".view").forEach((section) => {
    section.classList.add("hidden");
  });

  targetView.classList.remove("hidden");

  document.querySelectorAll(".nav-link").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === viewName);
  });

  const titles = {
    dashboard: "Your dashboard",
    roadmap: "My learning roadmap",
    catalog: "Course catalog",
    audit: "Advisor audit",
    profile: "Student profile"
  };
  $("pageTitle").textContent = titles[viewName] || "SkillSprout";

  if (viewName === "dashboard") renderDashboard();
  if (viewName === "roadmap") renderRoadmap();
  if (viewName === "catalog") renderCatalog();
  if (viewName === "audit") renderAudit();
  if (viewName === "profile") fillProfileForm();

  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll("[data-view]").forEach((button) => {
  button.addEventListener("click", () => openView(button.dataset.view));
});

document.querySelectorAll("[data-goto]").forEach((button) => {
  button.addEventListener("click", () => openView(button.dataset.goto));
});

function getProgressSummary() {
  const enrolledCourses = state.enrolled.map(getCourse).filter(Boolean);
  const totalCredits = enrolledCourses.reduce((sum, item) => sum + item.credits, 0);
  const completedCredits = enrolledCourses
    .filter((item) => isCourseComplete(item.code))
    .reduce((sum, item) => sum + item.credits, 0);

  const totalModules = enrolledCourses.length * MODULE_COUNT;
  const finishedModules = enrolledCourses.reduce(
    (sum, item) => sum + Math.min(MODULE_COUNT, modulesDone(item.code).length),
    0
  );

  return {
    enrolledCourses,
    totalCredits,
    completedCredits,
    totalModules,
    finishedModules,
    percentage: totalModules ? Math.round((finishedModules / totalModules) * 100) : 0
  };
}

function renderDashboard() {
  const summary = getProgressSummary();
  $("completedCredits").innerHTML =
    `${summary.completedCredits} <small>/ ${summary.totalCredits}</small>`;

  const creditPct = summary.totalCredits
    ? (summary.completedCredits / summary.totalCredits) * 100
    : 0;
  $("creditBar").style.width = `${creditPct}%`;

  $("enrolledCount").textContent = summary.enrolledCourses.length;
  $("progressPercent").textContent = `${summary.percentage}%`;

  // Smooth SVG circle progress animation (circumference = 2 * pi * 31 ≈ 194.78)
  const ringCircle = $("progressRingCircle");
  if (ringCircle) {
    const circumference = 194.78;
    const offset = circumference - (summary.percentage / 100) * circumference;
    ringCircle.style.strokeDashoffset = offset;
  }

  // Update enrolled dot indicators
  const dotsContainer = $("enrolledDots");
  if (dotsContainer) {
    const activeDots = Math.min(5, summary.enrolledCourses.length);
    dotsContainer.innerHTML = Array.from({ length: 5 }, (_, idx) =>
      `<span class="${idx < activeDots ? "active" : ""}">●</span>`
    ).join("");
  }

  $("avatar").textContent = (state.profile.name || "S").trim().charAt(0).toUpperCase();
  $("welcomeText").textContent =
    `Welcome back, ${state.profile.name || "learner"}. Your ${state.profile.career} learning path is ready.`;

  const next = summary.enrolledCourses.find((item) => !isCourseComplete(item.code));
  $("nextCourse").innerHTML = next
    ? `<h4>${escapeHtml(next.title)}</h4>
       <p>${escapeHtml(next.code)} · ${next.credits} credits · ${next.difficulty} level</p>
       <div class="course-meta"><span class="chip">${escapeHtml(next.track)}</span>
       <span class="chip">${modulesDone(next.code).length}/${MODULE_COUNT} modules done</span></div>`
    : `<h4>Choose your next course</h4><p>Visit the catalog and enroll in a course that is unlocked.</p>`;

  const weeklyHours = summary.enrolledCourses.reduce((sum, item) => {
    return sum + ({ Easy: 2, Medium: 3, Hard: 5 }[item.difficulty] || 2);
  }, 0);
  $("studyHours").textContent = weeklyHours;
  $("hoursBreakdown").innerHTML = Array.from(
    { length: Math.max(5, Math.min(12, weeklyHours)) },
    (_, index) => `<i style="--i:${index}; opacity:${index < weeklyHours ? 1 : 0.25}"></i>`
  ).join("");
}

function courseActionButton(item) {
  const enrolled = isEnrolled(item.code);
  const complete = isCourseComplete(item.code);
  const unlocked = isPrerequisiteComplete(item.code);

  if (complete) return `<button type="button" class="road-action" disabled>Completed</button>`;
  if (enrolled) {
    return `<button type="button" class="road-action" data-open-modules="${escapeHtml(item.code)}">Modules ${modulesDone(item.code).length}/${MODULE_COUNT}</button>`;
  }
  if (unlocked) {
    return `<button type="button" class="road-action" data-enroll="${escapeHtml(item.code)}">Enroll</button>`;
  }
  return `<button type="button" class="road-action" disabled title="Complete prerequisites first">Locked</button>`;
}

function renderRoadmap() {
  const plan = createSemesterPlan();
  const summary = getProgressSummary();

  $("roadmapSummary").innerHTML = `
    <div class="summary-chip" style="--i:0"><b>${escapeHtml(state.profile.career)}</b><small>Career pathway</small></div>
    <div class="summary-chip" style="--i:1"><b>${summary.enrolledCourses.length}</b><small>Enrolled courses</small></div>
    <div class="summary-chip" style="--i:2"><b>${summary.completedCredits}/${summary.totalCredits}</b><small>Completed credits</small></div>
    <div class="summary-chip" style="--i:3"><b>${summary.percentage}%</b><small>Module progress</small></div>`;

  $("roadmapContainer").innerHTML = plan.map((items, index) => {
    const semesterCredits = items.reduce((sum, item) => sum + item.credits, 0);
    return `<article class="semester-card" style="--i:${index}">
      <div class="semester-head"><div><h3>Semester ${index + 1}</h3>
      <small>${semesterCredits} suggested credits · ${items.length} courses</small></div>
      <span class="tiny-pill">${items.filter((item) => isCourseComplete(item.code)).length}/${items.length} complete</span></div>
      <div class="semester-courses">
        ${items.map((item, courseIdx) => `<div class="road-course ${isCourseComplete(item.code) ? "done" : ""} ${!isPrerequisiteComplete(item.code) && !isEnrolled(item.code) ? "locked" : ""}" style="--i:${courseIdx}">
          <span class="course-status">${isCourseComplete(item.code) ? "✓" : isEnrolled(item.code) ? "↗" : isPrerequisiteComplete(item.code) ? "＋" : "🔒"}</span>
          <div class="road-course-info"><b>${escapeHtml(item.title)}</b>
          <small>${escapeHtml(item.code)} · ${item.credits} credits · ${escapeHtml(item.difficulty)}</small></div>
          ${courseActionButton(item)}
        </div>`).join("")}
      </div>
    </article>`;
  }).join("");
}

function renderCatalog() {
  const search = $("searchInput").value.trim().toLowerCase();
  const difficulty = $("difficultyFilter").value;
  const credits = $("creditFilter").value;
  const track = $("trackFilter").value;

  const filtered = COURSES.filter((item) => {
    const searchable = [
      item.code, item.title, item.track, ...item.skills
    ].join(" ").toLowerCase();

    return searchable.includes(search) &&
      (!difficulty || item.difficulty === difficulty) &&
      (!credits || String(item.credits) === credits) &&
      (!track || item.track === track);
  });

  $("catalogCount").textContent = `${filtered.length} course${filtered.length === 1 ? "" : "s"}`;

  if (!filtered.length) {
    $("catalogGrid").innerHTML = `<div class="empty-state">No courses match those filters. Try another search.</div>`;
    $("pager").innerHTML = "";
    return;
  }

  const pages = Math.ceil(filtered.length / PAGE_SIZE);
  catalogPage = Math.min(Math.max(1, catalogPage), pages);
  const visible = filtered.slice((catalogPage - 1) * PAGE_SIZE, catalogPage * PAGE_SIZE);
  $("pager").innerHTML = pages < 2 ? "" : `<button type="button" data-page="${catalogPage - 1}" ${catalogPage === 1 ? "disabled" : ""}>← Previous</button>
    <span>Page ${catalogPage} of ${pages}</span>
    <button type="button" data-page="${catalogPage + 1}" ${catalogPage === pages ? "disabled" : ""}>Next →</button>`;

  $("catalogGrid").innerHTML = visible.map((item, idx) => {
    const enrolled = isEnrolled(item.code);
    const complete = isCourseComplete(item.code);
    const unlocked = isPrerequisiteComplete(item.code);
    const buttonText = complete ? "Completed" : enrolled ? "Enrolled" : unlocked ? "＋ Enroll" : "🔒 Locked";

    return `<article class="catalog-card" style="--i:${Math.min(idx, 12)}">
      <div class="catalog-card-top"><span class="course-code">${escapeHtml(item.code)}</span>
      <span class="difficulty ${item.difficulty}">${item.difficulty}</span></div>
      <h3>${escapeHtml(item.title)}</h3>
      <p>${item.prerequisites.length ? "Prerequisites: " + item.prerequisites.map(escapeHtml).join(", ") : "No prerequisites · Good foundation course"}</p>
      <div class="course-meta"><span class="chip">${escapeHtml(item.track)}</span>
        ${item.skills.slice(0, 2).map((skill) => `<span class="chip">${escapeHtml(skill)}</span>`).join("")}
      </div>
      <div class="catalog-bottom"><small>${item.credits} credits</small>
        <button type="button" data-enroll="${escapeHtml(item.code)}" ${enrolled || complete || !unlocked ? "disabled" : ""}>${buttonText}</button>
      </div>
    </article>`;
  }).join("");
}

["searchInput", "difficultyFilter", "creditFilter", "trackFilter"].forEach((id) => {
  $(id).addEventListener(id === "searchInput" ? "input" : "change", () => { catalogPage = 1; renderCatalog(); });
});

function enrollCourse(code) {
  const item = getCourse(code);
  if (!item) return;

  if (!isPrerequisiteComplete(code)) {
    const missing = item.prerequisites.filter((required) => !isCourseComplete(required));
    notify("Complete prerequisite course(s): " + missing.join(", "));
    return;
  }

  if (isEnrolled(code)) {
    notify("You are already enrolled in this course.");
    return;
  }

  state.enrolled.push(code);
  if (!Array.isArray(state.completedModules[code])) {
    state.completedModules[code] = [];
  }
  saveState();
  notify(`${item.code} added to your learning plan.`);
  renderEverything();
}

function openModuleChecklist(code) {
  const item = getCourse(code);
  if (!item || !isEnrolled(code)) return;

  // Prevent duplicate modals
  document.querySelectorAll(".module-modal-backdrop").forEach((el) => el.remove());

  const current = new Set(modulesDone(code));
  const lines = Array.from({ length: MODULE_COUNT }, (_, index) => {
    const number = index + 1;
    const checked = current.has(number) ? "checked" : "";
    return `<label class="module-option"><input type="checkbox" data-module="${number}" ${checked}>
      <span>Module ${number}</span><small>${current.has(number) ? "Completed" : "Mark complete"}</small></label>`;
  }).join("");

  const panel = document.createElement("div");
  panel.className = "module-modal-backdrop";
  panel.innerHTML = `<section class="module-modal" role="dialog" aria-modal="true" aria-label="Course modules">
    <button type="button" class="modal-close" aria-label="Close">×</button>
    <span class="eyebrow">COURSE CHECKLIST</span><h3>${escapeHtml(item.title)}</h3>
    <p class="muted">Tick off each module as you finish it. Each module is worth 25% of this course.</p>
    <div class="module-options">${lines}</div>
    <div class="modal-progress"><span id="modalProgress">${current.size * 25}% complete</span><div class="progress-track"><i style="width:${current.size * 25}%"></i></div></div>
    <button type="button" class="button button-dark modal-done">Save progress</button>
  </section>`;
  const opener = document.activeElement;
  document.body.appendChild(panel);
  panel.querySelector("input, button").focus();

  const closeModal = () => {
    panel.classList.add("closing");
    document.removeEventListener("keydown", onEsc);
    setTimeout(() => panel.remove(), 220);
    if (opener && opener.focus) opener.focus();
  };

  const onEsc = (e) => {
    if (e.key === "Escape") closeModal();
  };
  document.addEventListener("keydown", onEsc);

  panel.addEventListener("click", (event) => {
    if (event.target === panel || event.target.closest(".modal-close")) closeModal();
  });

  panel.querySelectorAll("[data-module]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const checkedCount = panel.querySelectorAll("[data-module]:checked").length;
      panel.querySelector("#modalProgress").textContent = `${checkedCount * 25}% complete`;
      panel.querySelector(".progress-track i").style.width = `${checkedCount * 25}%`;
      const labelSmall = checkbox.closest(".module-option")?.querySelector("small");
      if (labelSmall) labelSmall.textContent = checkbox.checked ? "Completed" : "Mark complete";
    });
  });

  panel.querySelector(".modal-done").addEventListener("click", () => {
    state.completedModules[code] = [...panel.querySelectorAll("[data-module]:checked")]
      .map((checkbox) => Number(checkbox.dataset.module));
    saveState();
    closeModal();
    notify(`${item.code} progress saved.`);
    renderEverything();
  });
}

document.addEventListener("click", (event) => {
  const enrollButton = event.target.closest("[data-enroll]");
  const moduleButton = event.target.closest("[data-open-modules]");

  const pageButton = event.target.closest("[data-page]");
  if (pageButton && !pageButton.disabled) { catalogPage = Number(pageButton.dataset.page); renderCatalog(); }
  if (enrollButton && !enrollButton.disabled) enrollCourse(enrollButton.dataset.enroll);
  if (moduleButton && !moduleButton.disabled) openModuleChecklist(moduleButton.dataset.openModules);
});

function fillProfileForm() {
  const profile = state.profile;
  $("studentName").value = profile.name || "";
  $("branch").value = profile.branch || "Computer Science & Engineering";
  $("semester").value = profile.semester || "1";
  $("experience").value = profile.experience || "beginner";
  $("career").value = profile.career || "Full-Stack Web";
}

$("profileForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const candidate = {
    name: $("studentName").value.trim(),
    branch: $("branch").value,
    semester: $("semester").value,
    experience: $("experience").value,
    career: $("career").value
  };
  const check = Core.validateProfile(candidate);
  $("nameError").textContent = check.errors.name || "";
  $("studentName").setAttribute("aria-invalid", String(Boolean(check.errors.name)));
  if (!check.valid) {
    notify("Please fix the highlighted field.");
    $("studentName").focus();
    return;
  }
  state.profile = candidate;

  saveState();
  renderEverything();
  notify("Profile saved. Your roadmap has been refreshed.");
  openView("roadmap");
});

$("printRoadmap").addEventListener("click", () => window.print());

$("resetData").addEventListener("click", () => {
  if (!window.confirm("Clear your enrolled courses and module progress?")) return;
  state.enrolled = [];
  state.completedModules = {};
  saveState();
  renderEverything();
  notify("Learning progress has been reset.");
});

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[character]));
}

function renderEverything() {
  renderDashboard();
  renderRoadmap();
  renderCatalog();
  renderAudit();
}

function renderAudit() {
  const result = Core.advisorAudit(state, COURSES);
  const icon = { critical: "⛔", warning: "⚠", info: "ℹ" };
  const tone = result.score >= 90 ? "good" : result.score >= 70 ? "mid" : "bad";
  $("auditSummary").innerHTML = `
    <div class="audit-score ${tone}"><b>${result.score}</b><small>/ 100</small></div>
    <div><h3>${escapeHtml(result.verdict)}</h3>
    <p class="muted">${result.coverage.pathComplete} of ${result.coverage.pathTotal} roadmap courses complete ·
    ${result.workload.activeCredits} active credits · ~${result.workload.hours} study hrs/week</p></div>`;
  $("auditList").innerHTML = result.findings.length
    ? result.findings.map((f) => `<li class="audit-item ${f.severity}"><span aria-hidden="true">${icon[f.severity]}</span>
        <div><b>${escapeHtml(f.message)}</b><small>${escapeHtml(f.fix)}</small></div>
        <span class="tiny-pill">${escapeHtml(f.severity)}</span></li>`).join("")
    : `<li class="audit-item good"><span aria-hidden="true">✓</span><div><b>No issues found.</b><small>Your plan is consistent and balanced.</small></div></li>`;
}

const catalogProblems = Core.validateCourses(COURSES);
if (catalogProblems.length || Core.topologicalSort(COURSES).hasCycle) {
  console.error("Course catalogue problems:", catalogProblems);
  notify("Course data has problems. Check courses.js.");
}

fillProfileForm();
renderEverything();

// If the backend is running, prefer its saved copy (it is validated server-side).
Api.load().then((remote) => {
  if (!remote) return;
  state = Core.sanitizeState(remote, COURSES, starterState);
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  renderEverything();
  fillProfileForm();
});
