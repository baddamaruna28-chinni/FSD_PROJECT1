/* SkillSprout backend (tier 2 + 3): Node http + built-in SQLite. No npm install needed (Node 22.5+).
   Run: node server.js    ->  http://localhost:3000 */
"use strict";
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const Core = require("./core.js");

const ROOT = __dirname;
const COURSES = vm.runInNewContext(fs.readFileSync(path.join(ROOT, "courses.js"), "utf8") + ";COURSES");
const STARTER = { profile: { name: "Yogi", branch: Core.BRANCHES[0], semester: "1", experience: "beginner", career: Core.CAREERS[0] },
  enrolled: ["CS101"], completedModules: { CS101: [1] } };
const MIME = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".txt": "text/plain" };
const PUBLIC_FILES = new Set(["index.html", "style.css", "app.js", "courses.js", "core.js", "api.js"]);
const HEADERS = {
  "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
  "Content-Security-Policy": "default-src 'self'; style-src 'self' https://fonts.googleapis.com 'unsafe-inline'; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'"
};

function createApp(dbFile = path.join(ROOT, "skillsprout.db")) {
  const db = new DatabaseSync(dbFile);
  db.exec(`CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, created_at INTEGER NOT NULL);
           CREATE TABLE IF NOT EXISTS students (token_hash TEXT PRIMARY KEY REFERENCES sessions(token_hash),
             state TEXT NOT NULL, updated_at INTEGER NOT NULL);`);
  const hash = (t) => crypto.createHash("sha256").update(t).digest("hex");
  const hits = new Map();                              // naive per-IP rate limiter
  const limited = (ip) => {
    const now = Date.now(), h = (hits.get(ip) || []).filter((t) => now - t < 60000);
    h.push(now); hits.set(ip, h); return h.length > 120;
  };
  const send = (res, code, body, extra = {}) => {
    res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store", ...HEADERS, ...extra });
    res.end(JSON.stringify(body));
  };
  const readBody = (req) => new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", (c) => { size += c.length; if (size > 50_000) { reject(Object.assign(new Error("Payload too large"), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on("end", () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString()) : {}); } catch { reject(Object.assign(new Error("Invalid JSON"), { status: 400 })); } });
  });
  const auth = (req) => {
    const m = /^Bearer ([A-Za-z0-9_-]{43})$/.exec(req.headers.authorization || "");
    if (!m) return null;
    const h = hash(m[1]);
    return db.prepare("SELECT token_hash FROM sessions WHERE token_hash = ?").get(h) ? h : null;
  };

  async function api(req, res, url) {
    if (url.pathname === "/api/health") return send(res, 200, { ok: true, courses: COURSES.length });
    if (url.pathname === "/api/courses" && req.method === "GET") {       // server-side pagination
      const page = Math.max(1, parseInt(url.searchParams.get("page")) || 1);
      const size = Math.min(50, Math.max(1, parseInt(url.searchParams.get("size")) || 12));
      return send(res, 200, { total: COURSES.length, page, size, items: COURSES.slice((page - 1) * size, page * size) });
    }
    if (url.pathname === "/api/session" && req.method === "POST") {
      const token = crypto.randomBytes(32).toString("base64url");
      db.prepare("INSERT INTO sessions VALUES (?, ?)").run(hash(token), Date.now());
      return send(res, 201, { token });
    }
    if (url.pathname === "/api/state") {
      const id = auth(req);
      if (!id) return send(res, 401, { error: "Missing or invalid session token" });
      if (req.method === "GET") {
        const row = db.prepare("SELECT state FROM students WHERE token_hash = ?").get(id);
        return send(res, 200, { state: row ? JSON.parse(row.state) : STARTER });
      }
      if (req.method === "PUT") {
        const body = await readBody(req);
        const check = Core.validateProfile(body?.state?.profile || {});
        if (!check.valid) return send(res, 422, { error: "Invalid profile", fields: check.errors });
        const clean = Core.sanitizeState(body.state, COURSES, STARTER);
        db.prepare("INSERT INTO students VALUES (?, ?, ?) ON CONFLICT(token_hash) DO UPDATE SET state = excluded.state, updated_at = excluded.updated_at")
          .run(id, JSON.stringify(clean), Date.now());
        return send(res, 200, { state: clean });
      }
    }
    if (url.pathname === "/api/audit" && req.method === "GET") {
      const id = auth(req);
      if (!id) return send(res, 401, { error: "Missing or invalid session token" });
      const row = db.prepare("SELECT state FROM students WHERE token_hash = ?").get(id);
      return send(res, 200, Core.advisorAudit(row ? JSON.parse(row.state) : STARTER, COURSES));
    }
    return send(res, 404, { error: "Not found" });
  }

  function serveStatic(req, res, url) {
    const name = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
    if (!PUBLIC_FILES.has(name)) { res.writeHead(404, HEADERS); return res.end("Not found"); }   // allow-list blocks traversal
    res.writeHead(200, { "Content-Type": (MIME[path.extname(name)] || "text/plain") + "; charset=utf-8", ...HEADERS });
    fs.createReadStream(path.join(ROOT, name)).pipe(res);
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost");
      if (limited(req.socket.remoteAddress)) return send(res, 429, { error: "Too many requests" });
      if (url.pathname.startsWith("/api/")) return await api(req, res, url);
      if (req.method !== "GET") { res.writeHead(405, HEADERS); return res.end(); }
      serveStatic(req, res, url);
    } catch (err) {
      send(res, err.status || 500, { error: err.status ? err.message : "Internal server error" });
    }
  });
  server.on("close", () => db.close());
  return server;
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createApp().listen(port, () => console.log(`SkillSprout running at http://localhost:${port}`));
}
module.exports = { createApp };
