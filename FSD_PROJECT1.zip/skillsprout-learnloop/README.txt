SKILLSPROUT - LEARNLOOP HACKATHON PROJECT (v2)
==============================================
Three tiers: Presentation (HTML/CSS/JS) -> Application (Node REST API) -> Data (SQLite).

FILES
  index.html / style.css / app.js   UI only: rendering, events, accessibility
  core.js     Pure logic (Kahn topological sort + cycle report, roadmap, semester
              plan, Advisor Audit, validation, sanitising). Shared by browser,
              server and tests.
  api.js      Frontend client; falls back to localStorage if no server is running
  courses.js  40-course catalogue
  server.js   Node backend: sessions, validated state API, audit API, pagination,
              SQLite storage, security headers, rate limit, body-size limit
  test/       28 automated tests (node:test): graph edge cases, audit, validation, API

RUN (Node 22.5+, no npm install needed)
  node server.js          -> http://localhost:3000   (full 3-tier mode)
  npm test                -> runs all tests
Static only (Live Server / python -m http.server): still works, data stays in localStorage.

API
  POST /api/session              issue anonymous bearer token (stored hashed)
  GET|PUT /api/state             load / save student state (validated + sanitised)
  GET /api/audit                 Advisor Audit for the stored student
  GET /api/courses?page=&size=   paginated catalogue
  GET /api/health

ADVISOR AUDIT RULES
  DATA/CYCLE, PREREQ, LOAD (>16 active credits), HOURS (>20/wk), HARD (>2 at once),
  LEVEL (beginner in Hard), OFFPATH, FOUNDATION, EMPTY, STALLED.
  Score = 100 minus 25/10/3 per critical/warning/info finding.
