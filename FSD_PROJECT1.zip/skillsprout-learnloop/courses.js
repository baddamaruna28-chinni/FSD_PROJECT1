const COURSES = [
  {
    "code": "CS101",
    "title": "Programming Fundamentals",
    "credits": 4,
    "difficulty": "Easy",
    "prerequisites": [],
    "skills": ["C", "Logic", "Problem Solving"],
    "track": "Core"
  },
  {
    "code": "CS102",
    "title": "Python Programming",
    "credits": 3,
    "difficulty": "Easy",
    "prerequisites": ["CS101"],
    "skills": ["Python", "Programming"],
    "track": "Core"
  },
  {
    "code": "CS103",
    "title": "Web Technologies",
    "credits": 3,
    "difficulty": "Easy",
    "prerequisites": ["CS101"],
    "skills": ["HTML", "CSS", "JavaScript"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS104",
    "title": "Discrete Mathematics",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": [],
    "skills": ["Logic", "Sets", "Graphs"],
    "track": "Core"
  },
  {
    "code": "CS105",
    "title": "Digital Logic Design",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": [],
    "skills": ["Digital Systems"],
    "track": "Core"
  },
  {
    "code": "CS106",
    "title": "Computer Organization",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS105"],
    "skills": ["Architecture"],
    "track": "Core"
  },
  {
    "code": "CS107",
    "title": "Data Structures",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS101"],
    "skills": ["C", "Algorithms"],
    "track": "Core"
  },
  {
    "code": "CS108",
    "title": "Object Oriented Programming",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS101"],
    "skills": ["Java", "OOP"],
    "track": "Core"
  },
  {
    "code": "CS109",
    "title": "Database Management Systems",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS101"],
    "skills": ["SQL", "Databases"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS110",
    "title": "Operating Systems",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS107", "CS106"],
    "skills": ["Linux", "Processes"],
    "track": "Core"
  },
  {
    "code": "CS111",
    "title": "Computer Networks",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS106"],
    "skills": ["Networking"],
    "track": "Core"
  },
  {
    "code": "CS112",
    "title": "Software Engineering",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS101"],
    "skills": ["SDLC", "Testing"],
    "track": "Core"
  },
  {
    "code": "CS113",
    "title": "JavaScript Essentials",
    "credits": 3,
    "difficulty": "Easy",
    "prerequisites": ["CS103"],
    "skills": ["JavaScript", "DOM"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS114",
    "title": "Frontend Development",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS103", "CS113"],
    "skills": ["React", "UI"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS115",
    "title": "Backend Development",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS109", "CS113"],
    "skills": ["Node.js", "APIs"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS116",
    "title": "REST API Design",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS115"],
    "skills": ["REST", "HTTP"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS117",
    "title": "Full-Stack Project I",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS114", "CS116"],
    "skills": ["React", "Node.js"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS118",
    "title": "Cloud Fundamentals",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS111"],
    "skills": ["Cloud", "Deployment"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS119",
    "title": "DevOps Basics",
    "credits": 3,
    "difficulty": "Hard",
    "prerequisites": ["CS118", "CS112"],
    "skills": ["CI/CD", "Docker"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS120",
    "title": "Web Security",
    "credits": 3,
    "difficulty": "Hard",
    "prerequisites": ["CS111", "CS115"],
    "skills": ["OWASP", "Security"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS121",
    "title": "Algorithms",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS107", "CS104"],
    "skills": ["Algorithms", "Complexity"],
    "track": "Core"
  },
  {
    "code": "CS122",
    "title": "Design and Analysis of Algorithms",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS121"],
    "skills": ["Big-O", "Optimization"],
    "track": "Core"
  },
  {
    "code": "CS123",
    "title": "Artificial Intelligence",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS102", "CS121"],
    "skills": ["AI", "Search"],
    "track": "AI & ML"
  },
  {
    "code": "CS124",
    "title": "Machine Learning",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS123"],
    "skills": ["ML", "Python"],
    "track": "AI & ML"
  },
  {
    "code": "CS125",
    "title": "Data Science",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS102", "CS109"],
    "skills": ["Python", "Analytics"],
    "track": "AI & ML"
  },
  {
    "code": "CS126",
    "title": "Statistics for Computing",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS104"],
    "skills": ["Statistics"],
    "track": "AI & ML"
  },
  {
    "code": "CS127",
    "title": "Deep Learning",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS124"],
    "skills": ["Neural Networks"],
    "track": "AI & ML"
  },
  {
    "code": "CS128",
    "title": "Cybersecurity Fundamentals",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS111"],
    "skills": ["Security", "Networking"],
    "track": "Cybersecurity"
  },
  {
    "code": "CS129",
    "title": "Ethical Hacking",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS128", "CS110"],
    "skills": ["Penetration Testing"],
    "track": "Cybersecurity"
  },
  {
    "code": "CS130",
    "title": "Cryptography",
    "credits": 3,
    "difficulty": "Hard",
    "prerequisites": ["CS104", "CS128"],
    "skills": ["Encryption"],
    "track": "Cybersecurity"
  },
  {
    "code": "CS131",
    "title": "Digital Forensics",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS128"],
    "skills": ["Forensics"],
    "track": "Cybersecurity"
  },
  {
    "code": "CS132",
    "title": "Mobile App Development",
    "credits": 4,
    "difficulty": "Medium",
    "prerequisites": ["CS108", "CS103"],
    "skills": ["Android", "Apps"],
    "track": "Software Development"
  },
  {
    "code": "CS133",
    "title": "UI/UX Design",
    "credits": 3,
    "difficulty": "Easy",
    "prerequisites": ["CS103"],
    "skills": ["Design", "Prototyping"],
    "track": "Software Development"
  },
  {
    "code": "CS134",
    "title": "Software Testing",
    "credits": 3,
    "difficulty": "Medium",
    "prerequisites": ["CS112", "CS108"],
    "skills": ["QA", "Automation"],
    "track": "Software Development"
  },
  {
    "code": "CS135",
    "title": "System Design",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS107", "CS109", "CS111"],
    "skills": ["Scalability"],
    "track": "Software Development"
  },
  {
    "code": "CS136",
    "title": "Git and Collaboration",
    "credits": 2,
    "difficulty": "Easy",
    "prerequisites": ["CS101"],
    "skills": ["Git", "GitHub"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS137",
    "title": "Responsive Web Design",
    "credits": 2,
    "difficulty": "Easy",
    "prerequisites": ["CS103"],
    "skills": ["CSS", "Responsive"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS138",
    "title": "Data Structures Lab",
    "credits": 2,
    "difficulty": "Medium",
    "prerequisites": ["CS107"],
    "skills": ["C", "Lab"],
    "track": "Core"
  },
  {
    "code": "CS139",
    "title": "Full-Stack Project II",
    "credits": 4,
    "difficulty": "Hard",
    "prerequisites": ["CS117", "CS119", "CS120"],
    "skills": ["Deployment", "Capstone"],
    "track": "Full-Stack Web"
  },
  {
    "code": "CS140",
    "title": "Professional Communication",
    "credits": 2,
    "difficulty": "Easy",
    "prerequisites": [],
    "skills": ["Communication"],
    "track": "Core"
  }
];
