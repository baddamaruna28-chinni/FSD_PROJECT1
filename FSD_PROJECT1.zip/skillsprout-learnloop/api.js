/* Thin client for the SkillSprout backend. If the page is opened without the
   server (Live Server, file://), every call resolves to null and the app keeps
   working from localStorage only. */
const Api = (() => {
  const TOKEN_KEY = "skillsprout_token";
  const online = location.protocol.startsWith("http");
  let token = null;
  try { token = localStorage.getItem(TOKEN_KEY); } catch (e) { /* storage blocked */ }

  async function call(method, url, body) {
    if (!online) return null;
    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: body ? JSON.stringify(body) : undefined
      });
      if (res.status === 401 && token) { token = null; return null; }
      return res.ok ? await res.json() : null;
    } catch (e) { return null; }                       // server not running
  }

  async function ensureSession() {
    if (token) return true;
    const data = await call("POST", "/api/session");
    if (!data || !data.token) return false;
    token = data.token;
    try { localStorage.setItem(TOKEN_KEY, token); } catch (e) { /* ignore */ }
    return true;
  }

  return {
    async load() { return (await ensureSession()) ? (await call("GET", "/api/state"))?.state ?? null : null; },
    async save(state) { return (await ensureSession()) ? (await call("PUT", "/api/state", { state }))?.state ?? null : null; },
    async audit() { return (await ensureSession()) ? await call("GET", "/api/audit") : null; }
  };
})();
