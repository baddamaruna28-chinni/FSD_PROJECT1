const test = require("node:test");
const assert = require("node:assert/strict");
const os = require("node:os"), path = require("node:path");
const { createApp } = require("../server.js");

let server, base, token;
const req = (p, o = {}) => fetch(base + p, { ...o, headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}), ...o.headers } });
test.before(async () => {
  server = createApp(path.join(os.tmpdir(), `ss-${Date.now()}.db`));
  await new Promise((r) => server.listen(0, r)); base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

test("health + paginated courses", async () => {
  assert.equal((await (await req("/api/health")).json()).ok, true);
  const d = await (await req("/api/courses?page=2&size=5")).json();
  assert.equal(d.items.length, 5); assert.equal(d.page, 2); assert.equal(d.total, 40);
  assert.equal((await (await req("/api/courses?size=9999")).json()).size, 50);
});
test("state requires a valid token", async () => {
  assert.equal((await req("/api/state")).status, 401);
  assert.equal((await req("/api/state", { headers: { Authorization: "Bearer " + "a".repeat(43) } })).status, 401);
});
test("session -> save -> load round trip, with server-side sanitising", async () => {
  token = (await (await req("/api/session", { method: "POST" })).json()).token;
  const state = { profile: { name: "Asha", branch: "Information Technology", semester: "2", experience: "basic", career: "AI & ML" },
    enrolled: ["CS101", "FAKE"], completedModules: { CS101: [1, 2, 77] } };
  const put = await req("/api/state", { method: "PUT", body: JSON.stringify({ state }) });
  assert.equal(put.status, 200);
  const got = (await (await req("/api/state")).json()).state;
  assert.deepEqual(got.enrolled, ["CS101"]); assert.deepEqual(got.completedModules.CS101, [1, 2]); assert.equal(got.profile.career, "AI & ML");
});
test("invalid profile is rejected with field errors (422)", async () => {
  const r = await req("/api/state", { method: "PUT", body: JSON.stringify({ state: { profile: { name: "<b>", career: "x" } } }) });
  assert.equal(r.status, 422); assert.ok((await r.json()).fields.name);
});
test("malformed JSON -> 400, oversized body -> 413", async () => {
  assert.equal((await req("/api/state", { method: "PUT", body: "{nope" })).status, 400);
  const big = await req("/api/state", { method: "PUT", body: JSON.stringify({ x: "a".repeat(60000) }) }).catch(() => ({ status: 413 }));
  assert.equal(big.status, 413);
});
test("audit endpoint returns a score", async () => {
  const a = await (await req("/api/audit")).json();
  assert.equal(typeof a.score, "number"); assert.ok(Array.isArray(a.findings));
});
test("static allow-list blocks traversal and server files", async () => {
  assert.equal((await req("/server.js")).status, 404);
  assert.equal((await req("/..%2fserver.js")).status, 404);
  assert.equal((await req("/")).status, 200);
  assert.ok((await req("/")).headers.get("content-security-policy"));
});
