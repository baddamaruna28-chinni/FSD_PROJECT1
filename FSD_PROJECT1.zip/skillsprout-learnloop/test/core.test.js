const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs"), vm = require("node:vm");
const Core = require("../core.js");
const COURSES = vm.runInNewContext(fs.readFileSync(__dirname + "/../courses.js", "utf8") + ";COURSES");
const c = (code, prerequisites = [], extra = {}) => ({ code, title: code, credits: 3, difficulty: "Easy", prerequisites, skills: [], track: "Core", ...extra });
const fresh = () => ({ profile: { name: "Asha", branch: Core.BRANCHES[0], semester: "1", experience: "beginner", career: "Full-Stack Web" }, enrolled: [], completedModules: {} });
const pos = (r, k) => r.orderedCodes.indexOf(k);

test("topologicalSort: empty graph", () => assert.deepEqual(Core.topologicalSort([]), { orderedCodes: [], hasCycle: false, cycle: [] }));
test("topologicalSort: linear chain", () => assert.deepEqual(Core.topologicalSort([c("C", ["B"]), c("B", ["A"]), c("A")]).orderedCodes, ["A", "B", "C"]));
test("topologicalSort: diamond respects both parents", () => {
  const r = Core.topologicalSort([c("D", ["B", "C"]), c("B", ["A"]), c("C", ["A"]), c("A")]);
  assert.ok(pos(r, "A") < pos(r, "B") && pos(r, "A") < pos(r, "C") && pos(r, "B") < pos(r, "D") && pos(r, "C") < pos(r, "D"));
});
test("topologicalSort: detects 2-cycle and names it", () => {
  const r = Core.topologicalSort([c("A", ["B"]), c("B", ["A"]), c("X")]);
  assert.equal(r.hasCycle, true); assert.deepEqual(r.cycle.sort(), ["A", "B"]);
});
test("topologicalSort: self loop is a cycle", () => assert.equal(Core.topologicalSort([c("A", ["A"])]).hasCycle, true));
test("topologicalSort: duplicate prerequisite does not double count", () => assert.equal(Core.topologicalSort([c("B", ["A", "A"]), c("A")]).hasCycle, false));
test("topologicalSort: ignores unknown prerequisites", () => assert.equal(Core.topologicalSort([c("A", ["GHOST"])]).hasCycle, false));

test("shipped catalogue is valid and acyclic", () => {
  assert.deepEqual(Core.validateCourses(COURSES), []);
  assert.equal(Core.topologicalSort(COURSES).hasCycle, false);
});
test("validateCourses reports duplicates, unknown and self prerequisites", () => {
  const p = Core.validateCourses([c("A", ["Z"]), c("A", ["A"])]);
  assert.ok(p.some((m) => /Duplicate/.test(m)) && p.some((m) => /unknown/.test(m)) && p.some((m) => /itself/.test(m)));
});

test("every recommended path is prerequisite-ordered for every career", () => {
  Core.CAREERS.forEach((career) => {
    const { courses, error } = Core.buildRecommendedPath(COURSES, career);
    assert.equal(error, null); assert.ok(courses.length > 0);
    const seen = new Set();
    courses.forEach((x) => { x.prerequisites.forEach((p) => assert.ok(seen.has(p), `${x.code} before ${p}`)); seen.add(x.code); });
  });
});
test("buildRecommendedPath surfaces cycles instead of crashing", () => {
  const r = Core.buildRecommendedPath([c("A", ["B"]), c("B", ["A"])], "Core");
  assert.deepEqual(r.courses, []); assert.match(r.error, /Circular/);
});
test("semester plan: prerequisites always in an earlier semester", () => {
  const { courses } = Core.buildRecommendedPath(COURSES, "Full-Stack Web");
  const plan = Core.createSemesterPlan(courses, 8), at = {};
  plan.forEach((s, i) => s.forEach((x) => (at[x.code] = i)));
  courses.forEach((x) => x.prerequisites.forEach((p) => assert.ok(at[p] < at[x.code], `${p} !< ${x.code}`)));
});
test("semester plan: respects the credit limit when room exists", () => {
  Core.createSemesterPlan(Core.buildRecommendedPath(COURSES, "AI & ML").courses, 8).forEach((s) =>
    assert.ok(s.reduce((n, x) => n + x.credits, 0) <= Core.SEMESTER_CREDIT_LIMIT));
});

test("sanitizeState: garbage in, safe state out", () => {
  const s = Core.sanitizeState({ profile: { name: "<img onerror=x>", career: "Hacker", semester: 99 }, enrolled: ["CS101", "CS101", "NOPE", 5],
    completedModules: { CS101: [1, 1, 9, "x", 2], NOPE: [1] } }, COURSES, fresh());
  assert.equal(s.profile.name.includes("<"), false); assert.equal(s.profile.career, "Full-Stack Web"); assert.equal(s.profile.semester, "1");
  assert.deepEqual(s.enrolled, ["CS101"]); assert.deepEqual(s.completedModules, { CS101: [1, 2] });
});
test("sanitizeState: null/array/string input never throws", () => [null, [], "x", 5, undefined].forEach((v) => assert.doesNotThrow(() => Core.sanitizeState(v, COURSES, fresh()))));

test("validateProfile accepts good and rejects bad input", () => {
  const ok = { ...fresh().profile, name: "Mary-Ann O'Neil" };
  assert.equal(Core.validateProfile(ok).valid, true);
  ["", "A", "<script>", "x".repeat(61), "1234"].forEach((name) => assert.equal(Core.validateProfile({ ...ok, name }).errors.name !== undefined, true, name));
  assert.equal(Core.validateProfile({ ...ok, semester: "9" }).valid, false);
  assert.equal(Core.validateProfile({ ...ok, career: "x" }).valid, false);
});

test("audit: empty student gets EMPTY warning, not a crash", () => {
  const a = Core.advisorAudit(fresh(), COURSES);
  assert.ok(a.findings.some((f) => f.rule === "EMPTY")); assert.ok(a.score < 100);
});
test("audit: critical when progress exists without prerequisites", () => {
  const s = fresh(); s.enrolled = ["CS102"]; s.completedModules = { CS102: [1] };
  const a = Core.advisorAudit(s, COURSES);
  assert.ok(a.findings.some((f) => f.rule === "PREREQ" && f.severity === "critical")); assert.equal(a.verdict !== "On track", true);
});
test("audit: healthy student is On track", () => {
  const s = fresh(); s.enrolled = ["CS101"]; s.completedModules = { CS101: [1, 2, 3, 4] };
  const a = Core.advisorAudit(s, COURSES);
  assert.equal(a.verdict, "On track"); assert.equal(a.coverage.pathComplete, 1);
});
test("audit: flags overload and cycles", () => {
  const big = [c("A", [], { credits: 4 }), c("B", [], { credits: 4 }), c("D", [], { credits: 4 }), c("E", [], { credits: 4 }), c("F", [], { credits: 4 })];
  const s = fresh(); s.enrolled = big.map((x) => x.code);
  assert.ok(Core.advisorAudit(s, big).findings.some((f) => f.rule === "LOAD"));
  assert.ok(Core.advisorAudit(fresh(), [c("A", ["B"]), c("B", ["A"])]).findings.some((f) => f.rule === "CYCLE"));
});
test("audit: beginner in a Hard course is flagged", () => {
  const hard = COURSES.find((x) => x.difficulty === "Hard"); const s = fresh(); s.enrolled = [hard.code];
  assert.ok(Core.advisorAudit(s, COURSES).findings.some((f) => f.rule === "LEVEL"));
});
